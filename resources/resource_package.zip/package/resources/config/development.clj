{:database {:classname    "org.postgresql.Driver"
            :subprotocol  "postgresql"
            :host         "localhost"
            :database     "$safeproject$_development"
            :user         "postgres"
            :password     ""} 
 :controller-ns  "$project$.controllers"}
