(ns $project$.migrations.order)

(def order [ "default" ])
