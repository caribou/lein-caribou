(ns caribou-api.core-test
  (:use clojure.test
        caribou-api.core))

(deftest a-test
  (testing "FIXME, I fail."
    (is (= 0 1))))