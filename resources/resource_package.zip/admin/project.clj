(defproject $project$-admin "0.1.0"
  :description "Flexible and adaptive admin for caribou-api"
  :url "http://github.com/antler/caribou-admin"
  :license {:name "Eclipse Public License"
            :url "http://www.eclipse.org/legal/epl-v10.html"}
  :dependencies [[org.clojure/clojure "1.4.0"]
                 [antler/caribou-admin "0.9.3"]]
  :resource-paths ["resources/" "../resources/"]
  :source-paths ["src" "../src"]
  :ring {:handler caribou.admin.core/app
         :servlet-name "$project$-admin"
         :join? false
         :init caribou.admin.core/init
         :port 33553})

