{:database {:classname    "org.postgresql.Driver"
            :subprotocol  "postgresql"
            :host         "localhost"
            :database     "$safeproject$_production"
            :user         "postgres"
            :password     "postgres"}
 :asset-dir      "assets"}
