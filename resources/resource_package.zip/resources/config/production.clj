{:database {:classname    "org.postgresql.Driver"
            :subprotocol  "postgresql"
            :host         "localhost"
            :database     "$safeproject$_production"
            :user         "postgres"
            :password     "postgres"}
 :template-dir   "site/resources/templates" 
 :controller-ns  "$project$.controllers"
 :public-dir     "site/resources/public"
 :api-public     "api/public"
 :asset-dir      "assets"
 :halo-key    "replace-with-halo-key"
 :halo-host   "http://localhost:33333"}
