{:database {:classname    "org.postgresql.Driver"
            :subprotocol  "postgresql"
            :host         "localhost"
            :database     "$safeproject$_staging"
            :user         "postgres"
            :password     "postgres"}
 :asset-dir      "assets"}
