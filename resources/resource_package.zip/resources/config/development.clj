{:database {:classname    "org.h2.Driver"
            :subprotocol  "h2"
            :host         "localhost"
            :database     "$safeproject$_development"
            :user         "h2"
            :password     ""} 
 :controller-ns  "$project$.controllers"}
