{:database {:classname    "org.postgresql.Driver"
            :subprotocol  "postgresql"
            :host         "localhost"
            :database     "caribou_development"
            :user         "postgres"
            :password     ""} 
 :controller-ns  "$project$.controllers"}
