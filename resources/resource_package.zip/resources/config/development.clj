{:logging {:loggers [{:type :stdout :level :debug}
                     ;; {:type :remote :host "beast.local" :level :debug}
                     ;; {:type :file :file "caribou-logging.out" :level :debug}
                     ]}
 :database {:classname    "org.h2.Driver"
            :subprotocol  "h2"
            :protocol     "file"
            :path         "/tmp/"
            :database     "$safeproject$_development"
            :host         "localhost"
            :subname      "file:/tmp/$safeproject$_development"
            :user         "h2"
            :password     ""}
 :controller {:namespace  "$project$.controllers" :reload true}
 :nrepl {:port 44444}
 :cache-templates :never}
