(ns skel.connect
  (:require [clojure.browser.repl :as repl]))

(repl/connect "http://localhost:44994/repl")
