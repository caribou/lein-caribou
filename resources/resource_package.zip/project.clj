(defproject $project$ "0.11.1"
  :description "The page routing ring handler for caribou"
  :dependencies [[org.clojure/clojure "1.4.0"]
                 [ring/ring-jetty-adapter "1.1.8"]
                 [org.immutant/immutant "0.10.0"]
                 [antler/caribou-frontend "0.11.1"]
                 [antler/caribou-admin "0.11.0"]
                 [antler/caribou-api "0.11.0"]
                 [swank-clojure "1.4.2"]]
  :jvm-opts ["-agentlib:jdwp=transport=dt_socket,server=y,suspend=n"]
  :source-paths ["src" "../src"]
  :resource-paths ["resources/" "../resources/"]
  :migration-namespace $project$.migrations
  :immutant {:context-path "/"}
  :min-lein-version "2.0.0"
  :ring {:handler $project$.core/handler
         :servlet-name "$project$-frontend"
         :init $project$.core/init
         :port 33333})
