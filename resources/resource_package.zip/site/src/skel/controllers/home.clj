(ns $project$.controllers.home
  (:use caribou.app.controller))

(defn home
  [params]
  (render params))
