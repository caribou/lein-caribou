(ns caribou-frontend.core-test
  (:use clojure.test
        caribou-frontend.core))

(deftest a-test
  (testing "FIXME, I fail."
    (is (= 0 1))))