(ns caribou.app.view)

(defn reset-template []
  (def template nil))

(reset-template)