(ns caribou.api.account
  (:require [caribou.model :as model]))

(defn crypt
  [raw]
  raw
  )