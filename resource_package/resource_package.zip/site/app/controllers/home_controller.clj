(use 'caribou.app.controller)

(controller :home
  :home (fn [request] request))