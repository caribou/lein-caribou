(ns caribou-admin.core-test
  (:use clojure.test
        caribou-admin.core))

(deftest a-test
  (testing "FIXME, I fail."
    (is (= 0 1))))